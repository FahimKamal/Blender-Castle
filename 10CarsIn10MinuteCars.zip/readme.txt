Checkout the video I make these 10 cars in 10 minutes in Blender 2.82: 
https://youtu.be/YALV3HqfdLY

Use these cars to learn from, but don't sell or give them to anyone.
Feel free to recommend the video so people can learn and download the cars themselves =)

Shameless plugs:
Checout my YouTube Channel: https://www.youtube.com/imphenzia
Follow me on Twitter: https://www.twitter.com/imphenzia
Visit my website: www.imphenzia.com
Listen to my music on Spotify (just search for Imphenzia)